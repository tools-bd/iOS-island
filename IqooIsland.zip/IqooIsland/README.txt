1. Open this folder in Android Studio (it will sync Gradle).
2. Build > Build APK(s), install on the phone.
3. Open the app, tap buttons 1-4 in order.
4. Vivo: Settings > Battery > Background power consumption > allow; also enable Autostart for the app.
Icon pack: apply from Nova/other launcher > Icon style. Add app mappings in assets/appfilter.xml.
