package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        val prefs = getSharedPreferences("island", Context.MODE_PRIVATE)
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Disable battery optimization") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("4. Start island") { startForegroundService(Intent(this, IslandService::class.java)) }
        btn("Test island") { IslandService.show("Hello", "Island is working") }
        fun slider(label: String, key: String, min: Int, max: Int, def: Int) {
            val tv = TextView(this).apply { text = "$label: ${prefs.getInt(key, def)}"; setPadding(0, 32, 0, 0) }
            val sb = SeekBar(this).apply {
                this.max = max - min; progress = prefs.getInt(key, def) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        val v = p + min
                        prefs.edit().putInt(key, v).apply()
                        tv.text = "$label: $v"
                        IslandService.instance?.reload()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            root.addView(tv); root.addView(sb)
        }
        slider("Upor-niche (Y)", "y", -20, 150, 8)
        slider("Bame-dane (X)", "x", -200, 200, 0)
        slider("Chora (Width)", "w", 60, 220, 120)
        slider("Uchota (Height)", "h", 20, 60, 34)
        btn("Reset position") {
            prefs.edit().clear().apply(); IslandService.instance?.reload(); recreate()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
