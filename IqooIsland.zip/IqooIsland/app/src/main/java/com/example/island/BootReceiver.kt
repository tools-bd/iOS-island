package com.example.island

import android.content.*
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Settings.canDrawOverlays(c)) c.startForegroundService(Intent(c, IslandService::class.java))
    }
}
