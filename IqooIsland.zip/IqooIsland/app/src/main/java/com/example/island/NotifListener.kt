package com.example.island

import android.app.Notification
import android.content.ComponentName
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private val cn by lazy { ComponentName(this, NotifListener::class.java) }
    private val sessListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        m.addOnActiveSessionsChangedListener(sessListener, cn)
        pick(m.getActiveSessions(cn))
    }

    override fun onListenerDisconnected() {
        runCatching { msm?.removeOnActiveSessionsChangedListener(sessListener) }
    }

    private fun pick(l: List<MediaController>?) {
        val c = l?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l?.firstOrNull()
        IslandService.setMedia(c)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.notification.category == Notification.CATEGORY_TRANSPORT) return
        val e = sbn.notification.extras
        val t = e.getCharSequence("android.title")?.toString() ?: return
        val b = e.getCharSequence("android.text")?.toString() ?: ""
        IslandService.show(t, b)
    }
}
